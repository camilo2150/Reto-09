from setuptools import setup, find_packages

setup(
    name="shape",
    version="1.0.0",
    description="Paquete de clases geométricas con decoradores en Python",
    author="Tu Nombre",
    packages=find_packages(),
    python_requires=">=3.6",
)
