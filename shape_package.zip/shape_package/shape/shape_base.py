import time

def tiempo_ejecucion(func):
    def wrapper(*args, **kwargs):
        inicio = time.time()
        resultado = func(*args, **kwargs)
        fin = time.time()
        print(f"Tiempo de ejecución de {func.__name__}: {fin - inicio:.6f} segundos")
        return resultado
    return wrapper

class Shape:
    _tipo = "Figura genérica"

    def __init__(self):
        pass

    @classmethod
    def set_tipo(cls, nuevo_tipo):
        cls._tipo = nuevo_tipo

    @classmethod
    def get_tipo(cls):
        return cls._tipo

    def compute_area(self):
        pass

    def compute_perimeter(self):
        pass
