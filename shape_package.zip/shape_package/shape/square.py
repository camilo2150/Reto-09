from .shape_base import Shape, tiempo_ejecucion

class Square(Shape):
    def __init__(self, side):
        self._side = side

    @property
    def side(self):
        return self._side

    @tiempo_ejecucion
    def compute_area(self):
        return self._side ** 2

    def compute_perimeter(self):
        return 4 * self._side
