from shape.rectangle import Rectangle
from shape.square import Square
from shape.shape_base import Shape

Shape.set_tipo("Figura bidimensional")

print(f"Tipo de forma actual: {Shape.get_tipo()}")

shapes = [
    Rectangle(4, 6),
    Square(5),
    Rectangle(2, 3),
    Square(7)
]

for shape in shapes:
    print(f"Figura: {type(shape).__name__}")
    print(f"Área: {shape.compute_area()}")
    print(f"Perímetro: {shape.compute_perimeter()}")
    print("-" * 40)
